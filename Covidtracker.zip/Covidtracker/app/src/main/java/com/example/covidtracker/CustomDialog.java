package com.example.covidtracker;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Iterator;



public class CustomDialog extends Dialog implements
        android.view.View.OnClickListener {
    private String TAG = "CustomDialog: ";
    public Activity c;
    public Dialog d;
    public Button update, cancel;
    private Person p;
    private EditText name, age, contact;
    private String namecpy;
    private DatabaseReference databaseReference;
    private ArrayAdapter adapter;

    public CustomDialog(Activity a, Person p, ArrayAdapter adapter) {
        super(a);
        // TODO Auto-generated constructor stub
        this.c = a;
        this.p = p;
        this.adapter = adapter;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog);

        databaseReference = FirebaseDatabase.getInstance().getReference("Person");
        update = (Button) findViewById(R.id.updateBtn);
        cancel = (Button) findViewById(R.id.cancelBtn);
        update.setOnClickListener(this);
        cancel.setOnClickListener(this);

        name = findViewById(R.id.editNameBtn);
        age = findViewById(R.id.editAgeBtn);
        contact = findViewById(R.id.editContactBtn);
        name.setText(p.getName());
        Integer x = new Integer(p.getAge());
        age.setText(x.toString());
        contact.setText(p.getContact());
        namecpy = name.getText().toString();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.updateBtn:
                Log.d(TAG, "stop -1");
                searchForTheItem();
                break;
            case R.id.cancelBtn:
                dismiss();
                break;
            default:
                break;
        }
        dismiss();
    }


    public void searchForTheItem(){
        Query query = databaseReference.orderByKey();
        Log.d(TAG+ "searchForTheItem", "stop 0");
        ValueEventListener queryValueListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> snapshotIterator = dataSnapshot.getChildren();
                Iterator<DataSnapshot> iterator = snapshotIterator.iterator();
                Log.d(TAG + "searchForTheItem", "stop 1");
                while (iterator.hasNext()) {
                    DataSnapshot next = (DataSnapshot) iterator.next();
                    Person p = next.getValue(Person.class);
                    Log.d(TAG+ "searchForTheItem", "stop 1.1");
                    if (namecpy.equals(p.getName())) {
                        Log.d(TAG+ "searchForTheItem", "stop 2");
                        Person p2 = new Person(name.getText().toString(), Integer.parseInt(age.getText().toString()), contact.getText().toString(), p.getDataInfectarii());
                        next.getRef().setValue(p2);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        query.addListenerForSingleValueEvent(queryValueListener);
    }
}
